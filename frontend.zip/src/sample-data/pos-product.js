const sampleData = [
  {
    name: "Marvel Bag",
    price: 1650,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
  {
    name: "Marvel Bag",
    price: 1660,
    img: 'https://images.unsplash.com/photo-1665707412910-32b77544a931'
  },
];

export { sampleData };

