const fileConfig = () => {
	const config = "laravel";
	// const config = "node";

	return config;
};

export default fileConfig;
