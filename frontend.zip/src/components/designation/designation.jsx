import PageTitle from "../page-header/PageHeader";
import GetAllDesignation from "./getAllDesignation";

const Designation = () => {
  return (
    <div>
      <PageTitle title='Back' />
      <GetAllDesignation />
    </div>
  );
};

export default Designation;
