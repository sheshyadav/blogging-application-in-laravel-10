import GetAllEmailConfig from "./GetAllEmailConfig";

export default function EmailConfig() {
  return (
   <GetAllEmailConfig/>
  )
}
