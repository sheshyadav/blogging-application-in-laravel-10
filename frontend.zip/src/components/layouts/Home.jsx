import Main from "./Main";

function Home() {
  return (
    <Main>
      <h2 className='dashboard'>Dash Board</h2>
    </Main>
  );
}

export default Home;
