import PageTitle from "../page-header/PageHeader";

import GetAllAccount from "./getAllAccount";

const Account = () => {
  return (
    <>
      <PageTitle title='Back' />
      <GetAllAccount />
    </>
  );
};

export default Account;
