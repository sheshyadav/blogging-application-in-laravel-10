import PageTitle from "../page-header/PageHeader";

import AddAward from "./AddAward";

const Award = () => {

  return (
    <div>
      <PageTitle title='Back' />
      <AddAward />
    </div>
  );
};

export default Award;
